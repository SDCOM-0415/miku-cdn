define([], function() {
    return window.emojioneVersion || '2.1.4';
});